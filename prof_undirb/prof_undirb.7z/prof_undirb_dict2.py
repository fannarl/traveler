# Write a Python script to add a key to a dictionary.

d = {0: 10, 1:20}
print(d)
d.update({2: 30})
print(d)