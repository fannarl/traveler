# Write a Python program to create a tuple.

x = ()
print(x)

tuplex = tuple()
print(tuplex)